import "jsr:@supabase/functions-js/edge-runtime.d.ts";

// PJD Maker — Wallet Ledger API (Module 37 : sécurité financière)
//
// Toute la logique financière sensible vit ICI, côté serveur, jamais dans le
// frontend. Le frontend ne fait jamais "balance = balance + montant" : il
// appelle cette fonction, qui recalcule tout à partir du grand livre
// (ledger_entries), applique les limites, et journalise (audit_log).
//
// Secrets à configurer :
//   supabase secrets set ADMIN_API_KEY=<clé longue et aléatoire> --project-ref lrlukgkaarzuqotefhlc
//
// Vérification d'identité : si un jeton Supabase Auth valide est fourni dans
// l'en-tête Authorization, l'appelant est identifié et son rôle réel (table
// profiles) est vérifié pour les actions admin. ADMIN_API_KEY reste un filet
// de sécurité transitoire pendant la migration des comptes existants.

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const ADMIN_API_KEY = Deno.env.get("ADMIN_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-admin-key",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

async function pg(path: string, init: RequestInit = {}) {
  const resp = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    ...init,
    headers: {
      apikey: SERVICE_ROLE_KEY,
      Authorization: `Bearer ${SERVICE_ROLE_KEY}`,
      "Content-Type": "application/json",
      Prefer: (init.headers as any)?.Prefer || "return=representation",
      ...(init.headers || {}),
    },
  });
  const text = await resp.text();
  const data = text ? JSON.parse(text) : null;
  return { ok: resp.ok, status: resp.status, data };
}

// Vérifie un jeton utilisateur (s'il est fourni) et renvoie son profil réel
// (id, role, store_id) via Supabase Auth + PostgREST — jamais via une donnée
// envoyée par le client.
async function verifyCaller(req: Request) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader) return null;
  const token = authHeader.replace("Bearer ", "");
  const userResp = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: ANON_KEY, Authorization: `Bearer ${token}` },
  });
  if (!userResp.ok) return null;
  const user = await userResp.json();
  const profRes = await pg(`profiles?id=eq.${user.id}&select=id,role,store_id`);
  const profile = profRes.data?.[0];
  return profile ? { userId: user.id, ...profile } : { userId: user.id, role: null, store_id: null };
}

async function writeAudit(actor: string, action: string, resource: string, resourceId: string, result: string, metadata: Record<string, unknown> = {}) {
  await pg("audit_log", {
    method: "POST",
    headers: { Prefer: "return=minimal" },
    body: JSON.stringify({ actor, action, resource, resource_id: resourceId, result, metadata }),
  });
}

async function getBalance(storeId: string) {
  const entriesRes = await pg(`ledger_entries?store_id=eq.${encodeURIComponent(storeId)}&select=amount`);
  const entries = Array.isArray(entriesRes.data) ? entriesRes.data : [];
  const balance = entries.reduce((s: number, e: any) => s + Number(e.amount), 0);
  const pendingRes = await pg(`withdrawal_requests?store_id=eq.${encodeURIComponent(storeId)}&status=in.(pending,under_review)&select=amount`);
  const pending = (Array.isArray(pendingRes.data) ? pendingRes.data : []).reduce((s: number, w: any) => s + Number(w.amount), 0);
  return { balance, pendingWithdrawals: pending, available: balance - pending };
}

async function getLimits() {
  const r = await pg("financial_limits?id=eq.1&select=*");
  return Array.isArray(r.data) && r.data[0] ? r.data[0] : { max_per_withdrawal: 500000, max_daily: 1000000, max_monthly: 5000000, manual_review_threshold: 300000 };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  let body: any;
  try { body = await req.json(); } catch { return json({ error: "Corps de requête invalide" }, 400); }

  const { action } = body;
  const caller = await verifyCaller(req); // null si aucun jeton fourni (compte legacy en migration)
  const isAdminKey = ADMIN_API_KEY && req.headers.get("x-admin-key") === ADMIN_API_KEY;
  const isAdminRole = caller?.role === "admin";
  const isAdmin = isAdminKey || isAdminRole;

  try {
    if (action === "get-balance") {
      const { storeId } = body;
      if (!storeId) return json({ error: "storeId requis" }, 400);
      return json(await getBalance(storeId));
    }

    if (action === "get-limits") {
      return json(await getLimits());
    }

    if (action === "get-history") {
      const { storeId } = body;
      if (!storeId) return json({ error: "storeId requis" }, 400);
      const r = await pg(`ledger_entries?store_id=eq.${encodeURIComponent(storeId)}&select=*&order=created_at.desc&limit=200`);
      return json({ entries: r.data });
    }

    if (action === "request-withdrawal") {
      const { storeId, amount, method } = body;
      if (!storeId || !amount || amount <= 0 || !method) return json({ error: "Paramètres invalides" }, 400);

      // Vérification d'identité opportuniste : si un jeton valide est fourni, la
      // boutique ciblée DOIT correspondre au profil authentifié. Sans jeton
      // (comptes legacy en cours de migration), la demande est encore acceptée
      // mais explicitement journalisée comme non vérifiée.
      const verified = !!caller;
      if (caller && caller.store_id && caller.store_id !== storeId) {
        await writeAudit(`user:${caller.userId}`, "withdrawal.request", "withdrawal_requests", "", "denied", { reason: "storeId ne correspond pas au profil authentifié", storeId });
        return json({ error: "Cette boutique ne correspond pas à votre compte authentifié." }, 403);
      }

      const { available } = await getBalance(storeId);
      if (amount > available) {
        await writeAudit(verified ? `user:${caller!.userId}` : `store:${storeId}:unverified`, "withdrawal.request", "withdrawal_requests", "", "denied", { reason: "solde insuffisant", amount, available });
        return json({ error: `Solde disponible insuffisant (${available} disponible).` }, 400);
      }

      const limits = await getLimits();
      if (amount > Number(limits.max_per_withdrawal)) return json({ error: `Le montant dépasse le maximum autorisé par retrait (${limits.max_per_withdrawal}).` }, 400);

      const dayAgo = new Date(Date.now() - 86400000).toISOString();
      const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString();
      const dailyRes = await pg(`withdrawal_requests?store_id=eq.${encodeURIComponent(storeId)}&requested_at=gte.${dayAgo}&status=neq.rejected&select=amount`);
      const monthlyRes = await pg(`withdrawal_requests?store_id=eq.${encodeURIComponent(storeId)}&requested_at=gte.${monthAgo}&status=neq.rejected&select=amount`);
      const dailyTotal = (dailyRes.data || []).reduce((s: number, w: any) => s + Number(w.amount), 0) + amount;
      const monthlyTotal = (monthlyRes.data || []).reduce((s: number, w: any) => s + Number(w.amount), 0) + amount;
      if (dailyTotal > Number(limits.max_daily)) return json({ error: "Limite de retrait quotidienne dépassée." }, 400);
      if (monthlyTotal > Number(limits.max_monthly)) return json({ error: "Limite de retrait mensuelle dépassée." }, 400);

      const needsReview = amount >= Number(limits.manual_review_threshold);
      const insertRes = await pg("withdrawal_requests", {
        method: "POST",
        body: JSON.stringify({ store_id: storeId, amount, method, status: needsReview ? "under_review" : "pending", risk_score: needsReview ? "moyen" : "faible" }),
      });
      const created = insertRes.data?.[0];
      await writeAudit(verified ? `user:${caller!.userId}` : `store:${storeId}:unverified`, "withdrawal.request", "withdrawal_requests", created?.id || "", "success", { amount, method, needsReview, identityVerified: verified });
      return json({ ok: true, withdrawal: created, identityVerified: verified });
    }

    // ---- Actions réservées admin : clé serveur OU rôle 'admin' vérifié via jeton ----
    if (!isAdmin) {
      await writeAudit(caller ? `user:${caller.userId}` : "unknown", action || "unknown", "", "", "denied", { reason: "droits administrateur requis" });
      return json({ error: "Action réservée à l'administration." }, 403);
    }
    const adminActor = isAdminRole ? `admin:${caller!.userId}` : "admin:legacy-key";

    if (action === "decide-withdrawal") {
      const { withdrawalId, decision } = body; // decision: 'approved' | 'rejected' | 'paid'
      if (!withdrawalId || !["approved", "rejected", "paid"].includes(decision)) return json({ error: "Paramètres invalides" }, 400);

      const wRes = await pg(`withdrawal_requests?id=eq.${withdrawalId}&select=*`);
      const w = wRes.data?.[0];
      if (!w) return json({ error: "Retrait introuvable." }, 404);
      if (w.status === "paid" || w.status === "rejected") return json({ error: `Ce retrait est déjà au statut final "${w.status}".` }, 400);

      await pg(`withdrawal_requests?id=eq.${withdrawalId}`, {
        method: "PATCH",
        headers: { Prefer: "return=minimal" },
        body: JSON.stringify({ status: decision, decided_at: new Date().toISOString(), decided_by: adminActor }),
      });

      if (decision === "approved" || decision === "paid") {
        // Idempotence : n'insérer l'écriture débit qu'une seule fois par retrait
        const existing = await pg(`ledger_entries?reference=eq.${withdrawalId}&type=eq.withdrawal&select=id`);
        if (!existing.data || existing.data.length === 0) {
          await pg("ledger_entries", {
            method: "POST",
            headers: { Prefer: "return=minimal" },
            body: JSON.stringify({ store_id: w.store_id, type: "withdrawal", amount: -Number(w.amount), currency: w.currency, reference: withdrawalId, note: `Retrait ${decision}`, created_by: adminActor }),
          });
        }
      }

      await writeAudit(adminActor, `withdrawal.${decision}`, "withdrawal_requests", withdrawalId, "success", { previousStatus: w.status });
      return json({ ok: true });
    }

    if (action === "record-adjustment") {
      const { storeId, amount, note } = body;
      if (!storeId || typeof amount !== "number" || amount === 0) return json({ error: "Paramètres invalides" }, 400);
      const insertRes = await pg("ledger_entries", {
        method: "POST",
        body: JSON.stringify({ store_id: storeId, type: "adjustment", amount, note: note || "Ajustement manuel", created_by: adminActor }),
      });
      await writeAudit(adminActor, "ledger.adjustment", "ledger_entries", insertRes.data?.[0]?.id || "", "success", { storeId, amount, note });
      return json({ ok: true, entry: insertRes.data?.[0] });
    }

    if (action === "update-limits") {
      const { limits } = body;
      await pg("financial_limits?id=eq.1", {
        method: "PATCH",
        headers: { Prefer: "return=minimal" },
        body: JSON.stringify({ ...limits, updated_at: new Date().toISOString() }),
      });
      await writeAudit(adminActor, "limits.update", "financial_limits", "1", "success", { limits });
      return json({ ok: true });
    }

    if (action === "get-audit-log") {
      const r = await pg("audit_log?select=*&order=created_at.desc&limit=200");
      return json({ entries: r.data });
    }

    if (action === "list-withdrawals") {
      const r = await pg("withdrawal_requests?select=*&order=requested_at.desc&limit=200");
      return json({ withdrawals: r.data });
    }

    return json({ error: "Action inconnue." }, 400);
  } catch (err) {
    return json({ error: String(err) }, 500);
  }
});

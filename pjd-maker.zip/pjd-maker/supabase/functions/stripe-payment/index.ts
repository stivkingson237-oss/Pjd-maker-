import "jsr:@supabase/functions-js/edge-runtime.d.ts";

// PJD Maker — (OBSOLETE) remplacée par la fonction "stripe-checkout".
// Conservée desactivée/inutilisée ; verify_jwt=false pour éviter les erreurs
// d'authentification si jamais elle est appelée par erreur.

Deno.serve(async (req: Request) => {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  return new Response(
    JSON.stringify({ error: "Cette fonction est obsolète. Utilisez stripe-checkout à la place." }),
    { status: 410, headers: { ...corsHeaders, "Content-Type": "application/json" } },
  );
});

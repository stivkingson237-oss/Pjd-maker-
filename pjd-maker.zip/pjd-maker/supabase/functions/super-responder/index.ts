// NOTE : cette fonction n'a PAS été créée par Claude dans la conversation
// PJD Maker — elle existait déjà sur le projet Supabase. Exportée ici telle
// quelle pour que l'état du dépôt corresponde à l'état réel du projet.
// verify_jwt=true sur cette fonction (contrairement aux autres de ce dépôt).

import { createClient } from "npm:@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

Deno.serve(async (req) => {
  try {
    if (req.method !== "POST") {
      return new Response("Method Not Allowed", { status: 405 });
    }

    const contentType = req.headers.get("content-type") || "";

    let data: Record<string, any> = {};

    if (contentType.includes("application/json")) {
      data = await req.json();
    } else {
      const formData = await req.formData();

      for (const [key, value] of formData.entries()) {
        data[key] = value;
      }
    }

    console.log("Notification Monetbil:", data);

    const paymentRef =
      data.payment_ref ||
      data.item_ref ||
      data.transaction_id ||
      null;

    const transactionId =
      data.transaction_id ||
      data.transaction_uuid ||
      null;

    const status = String(
      data.status || ""
    ).toLowerCase();

    let paymentStatus = "pending";

    if (
      status === "success" ||
      status === "successful" ||
      status === "completed"
    ) {
      paymentStatus = "paid";
    } else if (
      status === "failed" ||
      status === "cancelled" ||
      status === "canceled"
    ) {
      paymentStatus = "failed";
    }

    if (paymentRef) {
      const { error } = await supabase
        .from("payments")
        .update({
          status: paymentStatus,
          monetbil_transaction_id: transactionId,
          updated_at: new Date().toISOString()
        })
        .eq("payment_ref", paymentRef);

      if (error) {
        console.error("Erreur Supabase:", error);

        return new Response(
          JSON.stringify({
            success: false,
            error: error.message
          }),
          {
            status: 500,
            headers: {
              "Content-Type": "application/json"
            }
          }
        );
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        status: paymentStatus
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json"
        }
      }
    );
  } catch (error) {
    console.error("Webhook error:", error);

    return new Response(
      JSON.stringify({
        success: false,
        error: String(error)
      }),
      {
        status: 500,
        headers: {
          "Content-Type": "application/json"
        }
      }
    );
  }
});

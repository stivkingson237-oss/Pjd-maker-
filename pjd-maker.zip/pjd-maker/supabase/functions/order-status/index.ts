import "jsr:@supabase/functions-js/edge-runtime.d.ts";

// PJD Maker — order payment status lookup (used by the client to poll
// whether a Stripe Checkout session has been paid). Read-only, uses the
// service role key server-side only — the stripe_sessions table itself
// has no public RLS policies.

const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) return json({ error: "Configuration Supabase manquante." }, 500);

  try {
    const { orderId } = await req.json();
    if (!orderId) return json({ error: "orderId requis." }, 400);

    const resp = await fetch(
      `${SUPABASE_URL}/rest/v1/stripe_sessions?order_id=eq.${encodeURIComponent(orderId)}&select=status,session_id,updated_at&order=updated_at.desc&limit=1`,
      { headers: { apikey: SERVICE_ROLE_KEY, Authorization: `Bearer ${SERVICE_ROLE_KEY}` } },
    );
    const rows = await resp.json();
    if (!Array.isArray(rows) || rows.length === 0) return json({ status: "unknown" });
    return json({ status: rows[0].status, sessionId: rows[0].session_id });
  } catch (err) {
    return json({ error: String(err) }, 500);
  }
});

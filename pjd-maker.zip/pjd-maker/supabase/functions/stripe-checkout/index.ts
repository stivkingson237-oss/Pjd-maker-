import "jsr:@supabase/functions-js/edge-runtime.d.ts";

// PJD Maker — Stripe Checkout Session creation (hosted page, PCI-safe).
// SECURITY: the Stripe SECRET key is read from an environment variable
// (Supabase Edge Function secret) and is NEVER exposed to the client.
// Configure it once via the Supabase CLI or Dashboard:
//   supabase secrets set STRIPE_SECRET_KEY=sk_test_xxx --project-ref lrlukgkaarzuqotefhlc

const STRIPE_SECRET_KEY = Deno.env.get("STRIPE_SECRET_KEY");
const STRIPE_API = "https://api.stripe.com/v1";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  if (!STRIPE_SECRET_KEY) {
    return json(
      { error: "STRIPE_SECRET_KEY n'est pas configurée côté serveur. Exécutez: supabase secrets set STRIPE_SECRET_KEY=sk_... --project-ref lrlukgkaarzuqotefhlc" },
      500,
    );
  }

  try {
    const { items, currency = "xof", orderId, customerEmail, successUrl, cancelUrl } = await req.json();

    if (!Array.isArray(items) || items.length === 0) {
      return json({ error: "Le panier est vide." }, 400);
    }
    if (!orderId) {
      return json({ error: "orderId requis." }, 400);
    }

    const zeroDecimalCurrencies = ["xof", "xaf", "jpy", "krw"];
    const isZeroDecimal = zeroDecimalCurrencies.includes(String(currency).toLowerCase());

    const params = new URLSearchParams();
    params.set("mode", "payment");
    params.set("success_url", successUrl || "https://example.com/success");
    params.set("cancel_url", cancelUrl || "https://example.com/cancel");
    params.set("metadata[orderId]", String(orderId));
    if (customerEmail) params.set("customer_email", String(customerEmail));

    let totalAmount = 0;
    items.forEach((item: { name: string; qty: number; price: number }, i: number) => {
      const unitAmount = isZeroDecimal ? Math.round(item.price) : Math.round(item.price * 100);
      totalAmount += unitAmount * item.qty;
      params.set(`line_items[${i}][price_data][currency]`, String(currency).toLowerCase());
      params.set(`line_items[${i}][price_data][product_data][name]`, item.name.slice(0, 250));
      params.set(`line_items[${i}][price_data][unit_amount]`, String(unitAmount));
      params.set(`line_items[${i}][quantity]`, String(item.qty));
    });

    const resp = await fetch(`${STRIPE_API}/checkout/sessions`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${STRIPE_SECRET_KEY}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params.toString(),
    });

    const data = await resp.json();

    if (!resp.ok) {
      return json({ error: data?.error?.message || "Erreur Stripe" }, resp.status);
    }

    // Record a pending row so the client can poll /order-status and the
    // webhook can later flip it to "paid" once Stripe confirms payment.
    if (SUPABASE_URL && SERVICE_ROLE_KEY) {
      await fetch(`${SUPABASE_URL}/rest/v1/stripe_sessions`, {
        method: "POST",
        headers: {
          apikey: SERVICE_ROLE_KEY,
          Authorization: `Bearer ${SERVICE_ROLE_KEY}`,
          "Content-Type": "application/json",
          Prefer: "resolution=merge-duplicates,return=minimal",
        },
        body: JSON.stringify({
          session_id: data.id,
          order_id: String(orderId),
          status: "pending",
          amount: totalAmount,
          currency: String(currency).toLowerCase(),
        }),
      });
    }

    return json({ url: data.url, sessionId: data.id });
  } catch (err) {
    return json({ error: String(err) }, 500);
  }
});

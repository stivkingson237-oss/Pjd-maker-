import "jsr:@supabase/functions-js/edge-runtime.d.ts";

// PJD Maker — Stripe webhook receiver.
// Verifies the Stripe signature server-side, then marks the matching
// stripe_sessions row as paid. Uses the auto-injected SUPABASE_SERVICE_ROLE_KEY
// (never exposed to the client) to write to Postgres via PostgREST.
//
// Configure once:
//   supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_xxx --project-ref lrlukgkaarzuqotefhlc
// Then in the Stripe Dashboard, add an endpoint pointing to this function's URL
// listening for the "checkout.session.completed" event.

const STRIPE_WEBHOOK_SECRET = Deno.env.get("STRIPE_WEBHOOK_SECRET");
const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });
}

async function hmacSha256Hex(key: string, message: string) {
  const enc = new TextEncoder();
  const cryptoKey = await crypto.subtle.importKey("raw", enc.encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", cryptoKey, enc.encode(message));
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function timingSafeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

async function verifyStripeSignature(rawBody: string, sigHeader: string | null, secret: string) {
  if (!sigHeader) return false;
  const parts = Object.fromEntries(sigHeader.split(",").map((p) => p.split("=") as [string, string]));
  const timestamp = parts["t"];
  const v1 = parts["v1"];
  if (!timestamp || !v1) return false;
  const expected = await hmacSha256Hex(secret, `${timestamp}.${rawBody}`);
  return timingSafeEqual(expected, v1);
}

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  if (!STRIPE_WEBHOOK_SECRET) return json({ error: "STRIPE_WEBHOOK_SECRET non configurée côté serveur." }, 500);
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) return json({ error: "Configuration Supabase manquante." }, 500);

  const rawBody = await req.text();
  const sigHeader = req.headers.get("stripe-signature");

  const valid = await verifyStripeSignature(rawBody, sigHeader, STRIPE_WEBHOOK_SECRET);
  if (!valid) return json({ error: "Signature Stripe invalide." }, 400);

  let event: any;
  try {
    event = JSON.parse(rawBody);
  } catch {
    return json({ error: "Corps de requête invalide." }, 400);
  }

  if (event.type === "checkout.session.completed" || event.type === "checkout.session.async_payment_succeeded") {
    const session = event.data?.object;
    const sessionId = session?.id;
    if (sessionId) {
      await fetch(`${SUPABASE_URL}/rest/v1/stripe_sessions?session_id=eq.${sessionId}`, {
        method: "PATCH",
        headers: {
          apikey: SERVICE_ROLE_KEY,
          Authorization: `Bearer ${SERVICE_ROLE_KEY}`,
          "Content-Type": "application/json",
          Prefer: "return=minimal",
        },
        body: JSON.stringify({ status: "paid", updated_at: new Date().toISOString() }),
      });
    }
  } else if (event.type === "checkout.session.expired") {
    const session = event.data?.object;
    const sessionId = session?.id;
    if (sessionId) {
      await fetch(`${SUPABASE_URL}/rest/v1/stripe_sessions?session_id=eq.${sessionId}`, {
        method: "PATCH",
        headers: {
          apikey: SERVICE_ROLE_KEY,
          Authorization: `Bearer ${SERVICE_ROLE_KEY}`,
          "Content-Type": "application/json",
          Prefer: "return=minimal",
        },
        body: JSON.stringify({ status: "expired", updated_at: new Date().toISOString() }),
      });
    }
  }

  return json({ received: true });
});

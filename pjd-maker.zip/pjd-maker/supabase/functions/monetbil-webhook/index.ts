// NOTE : cette fonction n'a PAS été créée par Claude dans la conversation
// PJD Maker — elle existait déjà sur le projet Supabase (probablement issue
// d'un autre outil/session travaillant sur le même projet). Exportée ici
// telle quelle pour que l'état du dépôt corresponde à l'état réel du projet.
// Elle référence une table "payments" et des colonnes qui ne sont pas
// documentées dans les migrations de ce dépôt.

import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const serviceKey = Deno.env.get("MONETBIL_SERVICE_KEY");
const response = (body: unknown, status=200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
const s=(v:unknown)=>v==null?null:String(v).trim()||null;
const uuid=(v:string|null)=>v && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(v)?v:null;
Deno.serve(async req=>{
  if(!["GET","POST"].includes(req.method)) return response({error:"method_not_allowed"},405);
  const input:Record<string,unknown>={}; const url=new URL(req.url); url.searchParams.forEach((v,k)=>input[k]=v);
  if(req.method==="POST"){
    const ct=req.headers.get("content-type")||"";
    if(ct.includes("application/json")) Object.assign(input, await req.json().catch(()=>({})));
    else (await req.text()).split("&").filter(Boolean).forEach(p=>{const [k,v]=p.split("="); if(k) input[decodeURIComponent(k)]=decodeURIComponent(v||"")});
  }
  const service=s(input.service), tx=s(input.transaction_id), txu=s(input.transaction_uuid), status=s(input.status)?.toLowerCase(), item=s(input.item_ref), user=s(input.user);
  const amount=Number(input.amount), fee=input.fee==null?0:Number(input.fee);
  if(serviceKey && service!==serviceKey) return response({error:"invalid_service"},401);
  if(!tx&&!txu) return response({error:"missing_transaction_id"},400);
  if(!status || !["success","cancelled","failed"].includes(status)) return response({error:"invalid_status"},400);
  if(!Number.isFinite(amount)||amount<0) return response({error:"invalid_amount"},400);
  let existing:any=null;
  if(tx) existing=(await supabase.from("payments").select("*").eq("monetbil_transaction_id",tx).maybeSingle()).data;
  if(!existing&&txu) existing=(await supabase.from("payments").select("*").eq("monetbil_transaction_uuid",txu).maybeSingle()).data;
  let order:any=null; const oid=uuid(item); if(oid) order=(await supabase.from("orders").select("id,user_id,total,status").eq("id",oid).maybeSingle()).data;
  if(existing&&Number(existing.amount)!==amount) return response({error:"amount_mismatch"},409);
  if(order&&Number(order.total)!==amount) return response({error:"order_amount_mismatch"},409);
  const userId=uuid(user)||existing?.user_id||order?.user_id||null;
  const completed=status==="success";
  const payload={user_id:userId,order_id:existing?.order_id||order?.id||null,amount,method:"monetbil",currency:s(input.currency)||"XAF",status:completed?"completed":"failed",tx_id:tx||existing?.tx_id||null,payment_ref:existing?.payment_ref||item,item_ref:item,phone:s(input.phone),operator:s(input.operator),monetbil_transaction_id:tx,monetbil_transaction_uuid:txu,fee:Number.isFinite(fee)?fee:0,statut:completed?"payé":"annulé",updated_at:new Date().toISOString()};
  const result=existing?await supabase.from("payments").update(payload).eq("id",existing.id):await supabase.from("payments").insert(payload);
  if(result.error) return response({error:"payment_write_failed"},500);
  if(order&&completed&&order.status!=="livré"){const r=await supabase.from("orders").update({status:"payé"}).eq("id",order.id); if(r.error)return response({error:"order_update_failed"},500);}
  return response({ok:true,transaction_id:tx,transaction_uuid:txu,status:completed?"completed":"failed"});
});

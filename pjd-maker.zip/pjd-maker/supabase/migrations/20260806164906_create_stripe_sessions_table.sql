create table if not exists public.stripe_sessions (
  session_id text primary key,
  order_id text not null,
  status text not null default 'pending',
  amount numeric,
  currency text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists stripe_sessions_order_id_idx on public.stripe_sessions (order_id);

alter table public.stripe_sessions enable row level security;
-- No policies: only the service_role key (used exclusively inside our Edge Functions) can read/write.
-- anon/authenticated clients have zero access to this table by design.

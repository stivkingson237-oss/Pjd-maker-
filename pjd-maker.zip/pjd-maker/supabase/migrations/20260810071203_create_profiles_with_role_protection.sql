-- 37.4 : rôles définis côté serveur, jamais acceptés depuis le frontend.
-- Un profil est lié 1:1 à un vrai compte Supabase Auth (auth.users).
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default '',
  phone text,
  role text not null default 'client' check (role in ('client','vendeur','les_deux','admin','support','finance','moderator')),
  store_id text,
  country text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- Chacun peut lire son propre profil (nécessaire pour que l'app sache qui est connecté).
create policy "profiles_select_own" on public.profiles
  for select using (auth.uid() = id);

-- Chacun peut modifier son propre profil, MAIS le rôle est protégé par le trigger ci-dessous :
-- un utilisateur normal ne peut jamais se transformer lui-même en admin.
create policy "profiles_update_own" on public.profiles
  for update using (auth.uid() = id);

-- Un nouvel utilisateur peut créer sa propre ligne de profil (à l'inscription),
-- toujours avec le rôle 'client' par défaut (le trigger empêche de forcer 'admin' ici aussi).
create policy "profiles_insert_own" on public.profiles
  for insert with check (auth.uid() = id);

-- Protection anti-élévation de privilège (37.4) : seule la service_role
-- (utilisée exclusivement dans les Edge Functions serveur) peut changer un rôle
-- vers 'admin', 'support', 'finance' ou 'moderator'. Un appel authentifié classique
-- (le navigateur d'un vendeur) ne peut jamais se l'attribuer, même en modifiant
-- la requête réseau à la main.
create or replace function public.prevent_role_self_escalation()
returns trigger as $$
begin
  if new.role is distinct from old.role then
    if new.role in ('admin','support','finance','moderator') and auth.role() <> 'service_role' then
      raise exception 'Seule une action serveur autorisée peut attribuer ce rôle.';
    end if;
  end if;
  new.updated_at = now();
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists trg_prevent_role_self_escalation on public.profiles;
create trigger trg_prevent_role_self_escalation
  before update on public.profiles
  for each row execute function public.prevent_role_self_escalation();

-- Même protection à l'insertion : impossible de s'auto-créer en tant qu'admin.
create or replace function public.prevent_role_self_escalation_insert()
returns trigger as $$
begin
  if new.role in ('admin','support','finance','moderator') and auth.role() <> 'service_role' then
    raise exception 'Seule une action serveur autorisée peut attribuer ce rôle.';
  end if;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists trg_prevent_role_self_escalation_insert on public.profiles;
create trigger trg_prevent_role_self_escalation_insert
  before insert on public.profiles
  for each row execute function public.prevent_role_self_escalation_insert();

revoke all on public.profiles from anon;
grant select, insert, update on public.profiles to authenticated;

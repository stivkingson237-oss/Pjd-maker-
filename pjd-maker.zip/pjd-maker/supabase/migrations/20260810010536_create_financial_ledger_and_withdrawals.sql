-- 37.13 / 37.14 : grand livre financier immuable, jamais un simple champ "balance"
create table if not exists public.ledger_entries (
  id uuid primary key default gen_random_uuid(),
  store_id text not null,
  type text not null check (type in ('sale','commission','withdrawal','withdrawal_reversed','refund','subscription','ai_usage','ad_spend','affiliate_percent','affiliate_bonus','adjustment')),
  amount numeric not null,              -- positif = crédit, négatif = débit
  currency text not null default 'XOF',
  reference text,                       -- ex: order id, withdrawal id
  note text,
  created_by text not null default 'system',  -- 'system' | 'admin:<id>' | 'webhook:stripe' etc.
  created_at timestamptz not null default now()
);
create index if not exists ledger_entries_store_idx on public.ledger_entries (store_id);
create index if not exists ledger_entries_reference_idx on public.ledger_entries (reference);

alter table public.ledger_entries enable row level security;
-- Aucune policy anon/authenticated : seule la service_role (utilisée exclusivement
-- côté serveur dans les Edge Functions) peut lire ou écrire. Le frontend n'a
-- structurellement aucun moyen d'insérer ou modifier une ligne du grand livre.
revoke all on public.ledger_entries from anon, authenticated;

-- 37.15 : demandes de retrait, transitions de statut contrôlées uniquement côté serveur
create table if not exists public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  store_id text not null,
  amount numeric not null,
  currency text not null default 'XOF',
  method text not null,
  status text not null default 'pending' check (status in ('pending','under_review','approved','rejected','paid')),
  risk_score text not null default 'faible' check (risk_score in ('faible','moyen','eleve')),
  requested_at timestamptz not null default now(),
  decided_at timestamptz,
  decided_by text,
  note text
);
create index if not exists withdrawal_requests_store_idx on public.withdrawal_requests (store_id);

alter table public.withdrawal_requests enable row level security;
revoke all on public.withdrawal_requests from anon, authenticated;

-- 37.17 : limites financières configurables (jamais codées en dur dans le frontend)
create table if not exists public.financial_limits (
  id int primary key default 1,
  max_per_withdrawal numeric not null default 500000,
  max_daily numeric not null default 1000000,
  max_monthly numeric not null default 5000000,
  manual_review_threshold numeric not null default 300000,
  updated_at timestamptz not null default now(),
  constraint single_row check (id = 1)
);
insert into public.financial_limits (id) values (1) on conflict (id) do nothing;
alter table public.financial_limits enable row level security;
revoke all on public.financial_limits from anon, authenticated;

-- 37.20 : journal d'audit non modifiable par les utilisateurs
create table if not exists public.audit_log (
  id uuid primary key default gen_random_uuid(),
  actor text not null,          -- ex: 'admin:xxx', 'system', 'webhook:stripe'
  action text not null,         -- ex: 'withdrawal.approve', 'ledger.adjust'
  resource text,                -- ex: 'withdrawal_requests'
  resource_id text,
  result text not null default 'success' check (result in ('success','denied','error')),
  metadata jsonb,
  created_at timestamptz not null default now()
);
create index if not exists audit_log_actor_idx on public.audit_log (actor);
create index if not exists audit_log_resource_idx on public.audit_log (resource, resource_id);

alter table public.audit_log enable row level security;
revoke all on public.audit_log from anon, authenticated;
-- Pas de policy UPDATE/DELETE définie nulle part -> même la service_role ne
-- devrait modifier ce journal qu'en INSERT depuis le code serveur de confiance.

# PJD Maker

Marketplace panafricaine multi-vendeurs (produits physiques, numériques, services) —
frontend React (artifact Claude) + backend Supabase (Edge Functions, Postgres, Auth).

## Structure du dépôt

```
pjd-maker/
├── src/
│   └── App.jsx              # Application React complète (boutique, tableaux de bord
│                             # client/vendeur/admin, IA, abonnements, paiements…)
├── supabase/
│   ├── functions/
│   │   ├── stripe-checkout/     # Crée une session de paiement Stripe hébergée
│   │   ├── stripe-webhook/      # Confirme les paiements Stripe (signature vérifiée)
│   │   ├── order-status/        # Le client interroge le statut d'une commande
│   │   ├── stripe-payment/      # OBSOLÈTE — remplacée par stripe-checkout, conservée désactivée
│   │   ├── wallet-ledger/       # Grand livre financier, retraits, limites, audit log
│   │   ├── monetbil-webhook/    # ⚠️ non créée par Claude — voir note ci-dessous
│   │   └── super-responder/     # ⚠️ non créée par Claude — voir note ci-dessous
│   └── migrations/
│       ├── 20260806164906_create_stripe_sessions_table.sql
│       ├── 20260810010536_create_financial_ledger_and_withdrawals.sql
│       └── 20260810071203_create_profiles_with_role_protection.sql
├── .gitignore
└── README.md
```

## ⚠️ Important : migrations manquantes dans ce dépôt

Le projet Supabase contient **3 migrations supplémentaires** que je (Claude) n'ai pas
créées dans cette conversation, et dont je n'ai donc pas le texte SQL source :

- `20260731224823_create_pjd_market_schema` — crée les tables `users`, `shops`,
  `digital_products`, `carts`, `cart_items`, `orders`, `order_items`, `payments`,
  `download_tokens`
- `20260731224853_enable_rls_all_tables`
- `20260812002851_add_payments_monetbil_webhook_indexes`

Ces tables et les fonctions `monetbil-webhook` / `super-responder` existaient déjà
sur le projet Supabase (probablement issues d'un autre outil ou d'une autre session
ayant travaillé sur le même projet). **Avant de pousser sur GitHub**, récupère
l'historique complet et exact avec la CLI Supabase :

```bash
supabase login
supabase link --project-ref lrlukgkaarzuqotefhlc
supabase db pull
```

Cela ajoutera les migrations manquantes dans `supabase/migrations/` avec leur vrai
contenu, pour que ce dépôt reflète fidèlement l'état de la base.

## Secrets à configurer (jamais dans le code)

```bash
supabase secrets set STRIPE_SECRET_KEY=sk_test_xxx --project-ref lrlukgkaarzuqotefhlc
supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_xxx --project-ref lrlukgkaarzuqotefhlc
supabase secrets set ADMIN_API_KEY=<clé longue aléatoire> --project-ref lrlukgkaarzuqotefhlc
```

Dans le Dashboard Stripe, ajoute un endpoint webhook pointant vers :
`https://lrlukgkaarzuqotefhlc.supabase.co/functions/v1/stripe-webhook`
écoutant `checkout.session.completed` et `checkout.session.expired`.

## Déployer les fonctions

```bash
supabase functions deploy stripe-checkout --no-verify-jwt
supabase functions deploy stripe-webhook --no-verify-jwt
supabase functions deploy order-status --no-verify-jwt
supabase functions deploy wallet-ledger --no-verify-jwt
```

## Compte administrateur

Un compte admin réel existe déjà dans Supabase Auth (`admin@pjdmaker.app`), avec le
rôle `admin` posé directement en base (impossible à obtenir depuis le frontend —
voir le trigger `prevent_role_self_escalation` dans la migration `profiles`).
Le mot de passe a été communiqué une seule fois lors de sa création ; change-le
depuis Supabase Dashboard → Authentication → Users si tu ne l'as plus.

## État de la sécurité (Module 37)

✅ Fait : grand livre financier immuable, retraits validés côté serveur avec limites
configurables, journal d'audit, protection anti-élévation de privilège, vrai compte
admin authentifié.

⚠️ Pas encore fait : isolation RLS complète vendeur⟷vendeur pour produits/commandes
(actuellement stockés côté client), authentification à deux facteurs réelle,
détection de fraude, rate limiting dédié. Voir l'historique de conversation pour le
détail des arbitrages.

## Frontend

`src/App.jsx` est un artifact React autonome (pas de bundler requis dans son
environnement d'origine — Claude.ai). Pour l'intégrer à un projet Vite/CRA/Next
classique, il faudra probablement :
- Extraire les données encodées en base64 (logo) vers des fichiers image séparés
- Adapter les imports (`lucide-react`, `recharts` sont utilisés)
- Remplacer `window.storage` (API de persistance propre aux artifacts Claude) par
  votre solution de stockage (Supabase, localStorage, etc.)
